package util;

public interface JavaFlex_Name {
	void viewCnt();	    // 조회수별
	

}
